 
// const express = require("express");

// const router = express.Router();
// const checkAuth = require("../middleware/check-auth");

// router.films((req, res, next) => {
//     checkAuth,
//     console.log(films);
// })
 